// @story #1889
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import path from 'node:path';
import {
  legacyPathFor,
  statePath as resolveStatePath,
  SHARED_DIR_SEGMENT,
  TMP_AITM_SEGMENT,
} from './paths.mjs';
import { clearActiveTask, getActiveTask, setActiveTask } from './session-state.mjs';
import {
  ACTOR_TIMING_FIELDS,
  actorTimingStateRecord,
  readActorTimingState,
  writeActorTimingState,
} from './lib/actor-timing-state.mjs';
import {
  currentSessionId,
  jsonlPath,
  markerPathFor,
  loadMarker,
  saveMarker,
  countWords,
  aiAppName,
} from './word-counter.mjs';

export const EMPTY_STATE = {
  active: null,
  lastActive: null,
  entryStartTs: null,
  wordsAtEntryStart: 0,
  totalActiveMinutes: 0,
  discoverBucket: null,
  // #475 AC1 — durable monotonic Word Marker. Carried across bindings and
  // stamped on EVERY timing row (including audit/lifecycle rows that have no
  // live session) so the cumulative total never collapses to 0. Lives in the
  // global ledger, not the per-session overlay, so it survives rebinds.
  lastWordMarker: 0,
  // #1142 — full-expansion accounting is a second durable cumulative cursor,
  // not a per-transcript raw total. Keeping it beside `lastWordMarker` prevents
  // a new session id from resetting Full Word Marker back to that session's 0.
  lastFullWordMarker: 0,
  // #475 AC2 — timestamp of the most recent `/task pause`. `resume` uses it to
  // compute the idle span of the pause window, then clears it.
  pausedAtTs: null,
};

// #475 AC1 — monotonic advance of the durable Word Marker. Never decreases:
// returns the larger of the prior durable value and the freshly-computed
// candidate. Non-numeric / negative inputs floor to 0.
export function advanceWordMarker(prev, candidate) {
  const p = Number.isFinite(Number(prev)) ? Math.max(0, Number(prev)) : 0;
  const c = Number.isFinite(Number(candidate)) ? Math.max(0, Number(candidate)) : 0;
  return Math.max(p, c);
}

export function stateFullWordMarker(state, marker = null) {
  const global = advanceWordMarker(state?.lastWordMarker, state?.lastFullWordMarker);
  const session = advanceWordMarker(marker?.words, marker?.wordsFull);
  return advanceWordMarker(global, session);
}

// #475 AC1 — read the durable Word Marker for audit/lifecycle rows emitted by
// verbs that hold a `projDir` (or nothing) rather than a loaded `state`/`statePath`
// (approve, reconcile, promote, hook events). Returns 0 on any failure so a row
// is still emitted. Callers that already have a loaded state should use
// `state.lastWordMarker ?? 0` directly instead of reloading.
export function durableWordMarker(projDir) {
  try {
    const sp = resolveStatePath(projDir);
    return loadState(sp).lastWordMarker ?? 0;
  } catch {
    return 0;
  }
}

export function durableWordMarkers(projDir) {
  try {
    const state = loadState(resolveStatePath(projDir));
    return {
      marker: state.lastWordMarker ?? 0,
      fullMarker: stateFullWordMarker(state),
    };
  } catch {
    return { marker: 0, fullMarker: 0 };
  }
}

// #1142 — one invariant for every transcript-boundary producer: the per-session
// line cursor identifies the unread tail, while the state/marker word values are
// durable cumulative bases. An available observation adds only that tail to
// both bases before advancing the cursor. An unavailable observation carries
// the known bases without fabricating growth or consuming the unread cursor.
export function computeTranscriptTailBank(state, marker, counted) {
  const priorMarker = advanceWordMarker(state?.lastWordMarker, marker?.words);
  const priorFullMarker = stateFullWordMarker(state, marker);
  const transcriptStatus = counted?.status ?? 'unavailable';
  const available = transcriptStatus === 'ok';
  const banked = available ? Math.max(0, Number(counted?.count) || 0) : 0;
  const fullBanked = available
    ? Math.max(0, Number(counted?.fullExpansion ?? counted?.count) || 0)
    : 0;
  return {
    banked,
    fullBanked,
    marker: advanceWordMarker(priorMarker, priorMarker + banked),
    fullMarker: advanceWordMarker(priorFullMarker, priorFullMarker + fullBanked),
    line: available ? Math.max(0, Number(counted?.totalLines) || 0) : (marker?.line ?? 0),
    transcriptStatus,
    fullMarkerAvailable: available,
  };
}

// EPIC #823 (C8, #832) — bank the UNINTERRUPTED transcript tail into the durable
// marker + per-sid cursor. The promote verbs (`develop`/`test`/`review`) never
// call `flushActiveToGH`, so context-words accrued since the last flush sit
// un-counted in the per-sid cursor when a phase closes. Called by the phase-pair
// writer (`emitPhasePairRows`) BEFORE it stamps the `<phase>:completed` row, so
// the completed row's Word-Marker cell — and the own-issue Δwords the close
// walker derives from it — include this trailing tail (Case 4: an uninterrupted
// develop span). Advancing the cursor makes the bank idempotent: a second close
// with no further words counts 0. Best-effort: any failure (no sid, unreadable
// transcript) returns the unchanged durable marker and never throws.
export function bankTranscriptTail(projDir) {
  const fallback = (transcriptStatus = 'unavailable') => ({
    banked: 0,
    fullBanked: 0,
    ...durableWordMarkers(projDir),
    transcriptStatus,
    fullMarkerAvailable: false,
  });
  try {
    const sid = currentSessionId();
    if (!sid) return fallback();
    const markerPath = markerPathFor(sid);
    const marker = loadMarker(markerPath);
    const counted = countWords(jsonlPath(sid), marker.line, { provider: aiAppName(), sid });
    if (counted.status !== 'ok') return fallback(counted.status);
    const sp = resolveStatePath(projDir);
    const state = loadState(sp);
    const bank = computeTranscriptTailBank(state, marker, counted);
    if (bank.marker !== state.lastWordMarker || bank.fullMarker !== state.lastFullWordMarker) {
      state.lastWordMarker = bank.marker;
      state.lastFullWordMarker = bank.fullMarker;
      saveState(state, sp);
    }
    // Advance even when the unread records contain only metadata. Cursor
    // progress is distinct from word growth and makes the operation idempotent.
    saveMarker(markerPath, bank.line, bank.marker, state.active, bank.fullMarker);
    return bank;
  } catch {
    return fallback();
  }
}

// Fields owned by per-session active-task.json (#212). The authoritative copy
// lives under .ai-task-manager/sessions/<sid>/active-task.json. During the
// one-release transition window we ALSO mirror them in the global state file
// so legacy readers (and tests that inspect the JSON directly) keep working.
// Reads overlay per-session over the legacy fallback, so the session record
// always wins when present.
// #218: `state` removed — the issue body's `aitm-last-known-state` marker is
// now the single source of truth. Stale `state` fields on disk are silently
// dropped on read.
const PER_SESSION_FIELDS = ['active', 'entryStartTs', 'wordsAtEntryStart'];
// #1889 The occupancy generation is binding authority, never shared timing state.
const WORKTREE_SESSION_FIELDS = [
  'worktreePath',
  'worktreeBranch',
  'worktreeResolvedAt',
  'bindingGenerationId',
];

function currentSid() {
  // #273 — delegate to the lone resolver so this writer agrees with the
  // activity-guard / move-state readers on which sid represents "this session".
  // Pre-#273 this branch returned `'default-session'` while readers used a
  // mtime-sorted .jsonl basename; the disagreement wedged sessions on bind.
  return currentSessionId();
}

function migrateLegacyFields(parsed) {
  const out = { ...parsed };
  if (out.planBucket != null && out.discoverBucket == null) {
    out.discoverBucket = out.planBucket;
  }
  delete out.planBucket;
  if (out.active === 'plan') out.active = 'discover';
  if (out.lastActive === 'plan') out.lastActive = 'discover';
  return out;
}

// Returns the project root from a state-file path. The state file lives at
// `<projDir>/.ai-task-manager/task-tracker-state.json` (or the legacy
// `<projDir>/.claude/task-tracker-state.json`). We derive `projDir` so the
// per-session active-task.json sits alongside, not in a stray location when
// callers pass an absolute path.
//
// #332: use `lastIndexOf`, not `indexOf`. For worktrees rooted under
// `<main>/.claude/worktrees/<wt>/`, the path contains TWO `/.claude/`
// segments — the outer worktree-host one and the inner per-worktree legacy
// state dir. The rightmost anchor is the one closest to the state file and is
// always the correct project root. `indexOf` returned the outer (`<main>`)
// segment, contaminating worktree session state into main.
export function projectDirForState(statePath) {
  const abs = path.isAbsolute(statePath) ? statePath : path.resolve(statePath);
  const norm = abs.split(path.sep).join('/');
  // #1873 A sanctioned isolated test host bounds all ancestor state lookup.
  const runtimeHostIdx = Math.max(
    norm.lastIndexOf(SHARED_DIR_SEGMENT + 'runtime/test-sandboxes/'),
    norm.lastIndexOf(SHARED_DIR_SEGMENT + 'runtime/test-fixtures/')
  );
  // #573: the state file now lives under `<projDir>/.tmp/aitm/state/`. Anchor on
  // the rightmost `/.tmp/aitm/` segment first (worktree-local wins over main, per
  // #332). Checked before the legacy `.ai-task-manager/`/`.claude/` containers so
  // a relocated state path resolves to its true project root.
  const tmpIdx = norm.lastIndexOf(TMP_AITM_SEGMENT);
  if (tmpIdx > runtimeHostIdx) return abs.slice(0, tmpIdx);
  // `.ai-task-manager/` is always a real state container — anchor on the
  // rightmost one (worktree-local wins over main, per #332).
  // #1873 — runtime test hosts are metadata directories, not state containers.
  for (let from = norm.length; ;) {
    const idx = norm.lastIndexOf(SHARED_DIR_SEGMENT, from);
    if (idx <= runtimeHostIdx) break;
    const after = norm.slice(idx + SHARED_DIR_SEGMENT.length);
    if (!after.startsWith('runtime/test-sandboxes/') && !after.startsWith('runtime/test-fixtures/'))
      return abs.slice(0, idx);
    from = idx - 1;
  }
  // `.claude/` is trickier: `<main>/.claude/worktrees/<wt>/…` uses `.claude`
  // as a worktree HOST, not a state container. A state file living deeper
  // under such a worktree (e.g. a test sandbox at `<wt>/.scratch/test/…/state.json`)
  // must NOT mis-anchor to `<main>`. Walk `.claude/` matches right-to-left and
  // skip any whose next segment is `worktrees/` (the host marker); the first
  // real container wins. Legacy inner state (`…/<wt>/.claude/state.json`) is
  // followed by the state file, so it still anchors correctly. (#486 follow-up)
  for (let from = norm.length; ;) {
    const idx = norm.lastIndexOf('/.claude/', from);
    if (idx <= runtimeHostIdx) break;
    const after = norm.slice(idx + '/.claude/'.length);
    if (!after.startsWith('worktrees/')) return abs.slice(0, idx);
    from = idx - 1;
  }
  return path.dirname(abs);
}

export function loadState(statePath) {
  let readPath = statePath;
  if (!existsSync(readPath)) {
    const legacy = legacyPathFor(statePath);
    if (legacy && existsSync(legacy)) readPath = legacy;
  }
  let parsed = {};
  if (existsSync(readPath)) {
    try {
      parsed = JSON.parse(readFileSync(readPath, 'utf8'));
    } catch {
      parsed = {};
    }
  }
  const base = { ...EMPTY_STATE, ...migrateLegacyFields(parsed) };
  for (const field of ACTOR_TIMING_FIELDS) delete base[field];
  Object.assign(base, EMPTY_STATE);
  // #218: silently drop any stale `state` field from on-disk JSON. The issue
  // body is now the single source of truth.
  delete base.state;
  // #1163 — checkout identity is per-session authority. Never inherit it from
  // the global compatibility ledger if an older writer happened to mirror it.
  for (const field of WORKTREE_SESSION_FIELDS) delete base[field];
  // Per-session overlay (#212). When a session-scoped active-task.json exists,
  // its values take precedence over any legacy fields surfaced from the global
  // file. Missing-dir tolerated by getActiveTask (returns null).
  const sid = currentSid();
  const projDir = projectDirForState(statePath);
  const ownTiming = readActorTimingState({ provider: aiAppName(), sid }, projDir);
  if (ownTiming) Object.assign(base, migrateLegacyFields(ownTiming));
  else {
    // Upgrade only this actor's validated cumulative cursor. The shared legacy
    // ledger cannot attribute another session's history to this actor.
    const cursor = loadMarker(markerPathFor(sid, projDir), {
      identity: { provider: aiAppName(), sid },
    });
    base.lastWordMarker = cursor.words;
    base.lastFullWordMarker = cursor.wordsFull;
  }
  const active = getActiveTask(sid, projDir);
  if (active && typeof active === 'object') {
    if (active.issue != null) {
      base.active = active.issue === 'plan' ? 'discover' : active.issue;
    }
    base.entryStartTs = active.entryStartTs ?? null;
    base.wordsAtEntryStart = active.wordsAtStart ?? 0;
    if (base.entryStartTs !== null) {
      delete base.paused;
      base.pausedAtTs = null;
    }
    for (const field of WORKTREE_SESSION_FIELDS) {
      if (active[field] != null) base[field] = active[field];
    }
  } else {
    base.active = null;
    base.entryStartTs = null;
    base.wordsAtEntryStart = 0;
  }
  return base;
}

export function saveState(state, statePath) {
  const sid = currentSid();
  const identity = { provider: aiAppName(), sid };
  const actorRecord = actorTimingStateRecord(identity, migrateLegacyFields(state));
  mkdirSync(path.dirname(statePath), { recursive: true });
  const projDir = projectDirForState(statePath);
  readActorTimingState(identity, projDir);
  const priorBinding = getActiveTask(sid, projDir);
  // Split: per-session triple goes to active-task.json; remainder stays in the
  // global ledger file.
  const hasActiveBinding =
    state.active != null ||
    state.entryStartTs != null ||
    (state.wordsAtEntryStart != null && state.wordsAtEntryStart !== 0);
  if (hasActiveBinding) {
    const worktreeFields = Object.fromEntries(
      WORKTREE_SESSION_FIELDS.filter(
        (field) =>
          state[field] != null || (field === 'bindingGenerationId' && Object.hasOwn(state, field))
      ).map((field) => [field, state[field]])
    );
    // A timing-state spread may change issue without replacing its old generation.
    // Never carry that prior issue authority into a different binding.
    if (
      priorBinding?.issue !== state.active &&
      worktreeFields.bindingGenerationId != null &&
      worktreeFields.bindingGenerationId === priorBinding?.bindingGenerationId
    )
      delete worktreeFields.bindingGenerationId;
    setActiveTask(
      sid,
      {
        ...(priorBinding?.issue === state.active ? priorBinding : {}),
        issue: state.active ?? null,
        entryStartTs: state.entryStartTs ?? null,
        wordsAtStart: state.wordsAtEntryStart ?? 0,
        ...worktreeFields,
      },
      projDir
    );
  } else {
    clearActiveTask(sid, projDir);
  }
  // Actor history is separate from binding so a pause can clear authority while
  // retaining only this actor's resume and word cursor evidence.
  writeActorTimingState(identity, projDir, actorRecord.state);
  void PER_SESSION_FIELDS;
  let previous = {};
  if (existsSync(statePath)) {
    try {
      previous = JSON.parse(readFileSync(statePath, 'utf8'));
    } catch {
      /* legacy unknown */
    }
  }
  const shared = Object.fromEntries(
    Object.entries(state).filter(([key]) => !ACTOR_TIMING_FIELDS.includes(key))
  );
  const globalPayload = { ...previous, ...shared };
  // #218: never persist `state` to disk — issue body is the source of truth.
  delete globalPayload.state;
  for (const field of WORKTREE_SESSION_FIELDS) delete globalPayload[field];
  writeFileSync(statePath, JSON.stringify(globalPayload, null, 2) + '\n', 'utf8');
}

// #407 — next-state for a successful NON-terminal verb (test, review) that
// closes the open timing session but MUST keep the issue bound. Resets
// `entryStartTs`/`wordsAtEntryStart` (session closed) and records `lastActive`,
// while preserving `active` so the following verb needs no intervening
// `start <N>` re-bind. Contrast `pause` (the sole explicit unbind), which
// nulls `active`. Pure; exported for the #407 regression test.
export function pauseTimingKeepBinding(state, ref) {
  return {
    ...state,
    active: ref,
    entryStartTs: null,
    wordsAtEntryStart: 0,
    lastActive: ref,
  };
}

export function clearActive(statePath) {
  const s = loadState(statePath);
  s.active = null;
  s.entryStartTs = null;
  s.wordsAtEntryStart = 0;
  s.discoverBucket = null;
  // keep lastActive; `state` is body-sourced (#218), not persisted here.
  saveState(s, statePath);
}
